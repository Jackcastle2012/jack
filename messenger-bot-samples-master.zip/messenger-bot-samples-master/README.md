# messenger-bot-samples
Example bots to demonstrate best practices for the [Messenger Platform](https://developers.facebook.com/docs/messenger-platform).
